#include "simlib.h"

#include "stdlib.h"

#define INTERNE 1
#define ARO 2
#define CHIR 3

Histogram prichod_p_int("Prichod pacientov - Interne oddelenie",0,1,24); //histogram casu(hodiny) prichodu pacientov Interne oddelenie
Histogram c_st2_int("Cakanie na starostlivost 2 - Interne oddelenie",0,1,15);//dlzka cakania na starostlivost2 Interne oddelenie
Histogram c_st1_int("Cakanie na starostlivost 1 - Interne oddelenie",0,1,20);//dlzka cakania na starostlivost1 Interne oddelenie
Histogram c_um_int("Cas umrtia pacientov - Interne oddelenie",0,1,24); // cas umrtia pacientov Interne oddelenie

Histogram prichod_p_aro("Prichod pacientov - ARO",0,1,24); //histogram casu(hodiny) prichodu pacientov Interne oddelenie
Histogram c_st2_aro("Cakanie na starostlivost 2 - ARO",0,1,15);//dlzka cakania na starostlivost2 Interne oddelenie
Histogram c_st1_aro("Cakanie na starostlivost 1 - ARO",0,1,20);//dlzka cakania na starostlivost1 Interne oddelenie
Histogram c_um_aro("Cas umrtia pacientov - ARO",0,1,24); // cas umrtia pacientov Interne oddelenie

Histogram prichod_p_chir("Prichod pacientov - Chirurgicke oddelenie",0,1,24); //histogram casu(hodiny) prichodu pacientov Chirurgicke oddelenie
Histogram c_st2_chir("Cakanie na starostlivost 2 - Chirurgicke oddelenie",0,1,15);//dlzka cakania na starostlivost2 Chirurgicke oddelenie
Histogram c_st1_chir("Cakanie na starostlivost 1 - Chirurgicke oddelenie",0,1,20);//dlzka cakania na starostlivost1 Chirurgicke oddelenie
Histogram c_um_chir("Cas umrtia pacientov - Chirurgicke oddelenie",0,1,24); // cas umrtia pacientov Chirurgicke oddelenie

class Pacient;

// timeout pre vytvorenie udalosti starostlivost 1
class St1Timeout : public Event
{
public:
St1Timeout(Pacient *to) : Event() , To(to) {
};
void Behavior();
Pacient *To;
};
// timeout pre vytvorenie udalosti starostlivost 2
class St2Timeout : public Event
{
public:
St2Timeout(Pacient *to) : Event() , To(to) {
};
void Behavior();
Pacient *To;
};


// funkcia vracia denny cas 0-23h
int hodin(int cas)
{
    return (cas / 60) %24;
}

// funkcia vrati (v minutach) kolko casu zostava do danej hodiny,napr do 8:00
int time_to(int hour,int from=(int)Time)
{
    int day=from / (60*24);
    if (hour< (from / 60 % 24)) day++;
    int temp=(hour*60+day*24*60) - from;

    return temp;

}
Store interne("Kapacita Interne oddelenie", 30);
Store sestry_int("Zdravotne sestry Interne oddelenie",6);
Store lekari_int("Lekari",3);

Store aro("Kapacita ARO oddelenie", 6);
Store sestry_aro("Zdravotne sestry ARO",2);
Store lekari_aro("Lekari ARO",1);

Store chir("Kapacita Chirurgicke oddelenie", 20);
Store sestry_chir("Zdravotne sestry Chirurgicke oddelenie",5);
Store lekari_chir("Lekari Chirurgicke oddelenie",5);

int vs_p_int = 0;  //pocet vsetkych pacientov Interne oddelenie
int hosp_p_int = 0; //pocet hospitalizovanych pacientov Interne oddelenie
int zomrelo_int = 0; //pocient pacientov kt. zomreli Interne oddelenie

int vs_p_aro = 0;  //pocet vsetkych pacientov ARO
int hosp_p_aro = 0; //pocet hospitalizovanych pacientov ARO
int zomrelo_aro = 0; //pocient pacientov kt. zomreli ARO

int vs_p_chir = 0;  //pocet vsetkych pacientov Chirurgicke oddelenie
int hosp_p_chir = 0; //pocet hospitalizovanych pacientov Chirurgicke oddelenie
int zomrelo_chir = 0; //pocient pacientov kt. zomreli Chirurgicke oddelenie


// proces Starostlivost1 - pacient potrebuje starostlivost sestry
class Starostlivost1 : public Process
{
    public:
int oddelenie;
    void Behavior()
        {
          double ac_time=Time;
          switch (oddelenie)
          {
              case INTERNE : Enter(sestry_int,1);c_st1_int(Time - ac_time);break;
              case ARO : Enter(sestry_aro,1);c_st1_aro(Time - ac_time);break;
              case CHIR : Enter(sestry_chir,1);c_st1_chir(Time - ac_time);break;
          }


          if (oddelenie == INTERNE)Wait(Uniform(5,10)); //trvanie starostlivosti1 na internom oddeleni
          if (oddelenie == ARO)Wait(Uniform(3,30));    //trvanie starostlivosti1 na ARO
          if (oddelenie == CHIR)Wait(Uniform(3,30));    //trvanie starostlivosti1 na chirurgickom oddeleni


          switch (oddelenie)
          {
              case INTERNE : Leave(sestry_int,1);break;
              case ARO : Leave(sestry_aro,1);break;
              case CHIR : Leave(sestry_chir,1);break;
          }
        }
};

// proces Starostlivost1 - pacient potrebuje starostlivost sestry a lekara
class Starostlivost2 : public Process
{
    public:
Starostlivost2(Pacient *to) : Process() , To(to) {
};

    void Behavior();
 Pacient *To;
 int oddelenie;
};

// Proces pacienta ktory prichadza na oddelenie
class Pacient : public Process
{
  public:
   int zivy;
   int oddelenie;
   St1Timeout *St1tm; // Starostlivost1 timeout
   St2Timeout *St2tm; // Starostlivost1 timeout
	void akce()
        {
        St1tm=new St1Timeout(this);
        St2tm=new St2Timeout(this);
            switch (oddelenie)
            {
                case INTERNE: {hosp_p_int++;
                               St1tm->Activate(Time + Uniform(2*60,4*60)); // nastav timeout pre Starostlivost1 interne odd.
                               St2tm->Activate(Time + Uniform(20*60,200*60)); // nastav timeout pre Starostlivost2 interne odd.
                               Enter(interne, 1);
                               Wait(Uniform(7*24*60,14*24*60)); // zostava na oddeleni 7-14 dni
                               break;
                              }
                case ARO:     {hosp_p_aro++;
                               St1tm->Activate(Time + Uniform(30,2*60)); // nastav timeout pre Starostlivost1 ARO
                               St2tm->Activate(Time + Uniform(12*60,48*60)); // nastav timeout pre Starostlivost2 ARO
                               Enter(aro, 1);
                               Wait(Uniform(2*24*60,10*24*60)); // zostava na oddeleni 2-10 dni

                               if (zivy && Random()<0.10) //10% pacientov po pobyte na ARO zostava este na internom oddeleni 3-5dni
                               {

                                   Enter(interne,1);
                                   St1tm->Cancel(); //zrusi casovace
                                   St2tm->Cancel();
                                   Leave(aro,1);    //presun z ARO oddelenia na interne
                                   oddelenie=INTERNE;
                                   St1tm=new St1Timeout(this);
                                   St1tm->Activate(Time + Uniform(2*60,4*60)); // nastav timeout pre Starostlivost1 ARO odd.
                                   Wait(Uniform(3*24*60,5*24*60)); // zostava na oddeleni 3-5 dni
                               }
                               break;
                              }
                case CHIR: {hosp_p_chir++;
                               St1tm->Activate(Time + Uniform(1*60,3*60)); // nastav timeout pre Starostlivost1 chir odd.
                               St2tm->Activate(Time + Uniform(40*60,300*60)); // nastav timeout pre Starostlivost2 chir odd.
                               Enter(chir, 1);
                               Wait(Uniform(10*24*60,18*24*60)); // zostava na oddeleni 10-18 dni
                               break;
                              }

            }

    if(zivy)
        {
		if (oddelenie == INTERNE)Leave(interne, 1); // ak nebolo miesto na oddeleni uvolnene smrtou,uvolnime teraz
		if (oddelenie == ARO)Leave(aro, 1);
		if (oddelenie == CHIR)Leave(chir, 1);

		St1tm->Cancel(); //zrusi casovace
	    St2tm->Cancel();
        }
        }

	void Behavior()
	{

		zivy=1;


		    if (oddelenie == INTERNE) // ak nieje volna kapacita,pacient je preposlany do inej nemocnice
                        {
                            vs_p_int++;
                            if (!interne.Full()) akce();
                        }
		    if (oddelenie == ARO) // ak nieje volna kapacita,pacient je preposlany do inej nemocnice
                        {
                            vs_p_aro++;
                            if (!aro.Full()) akce();
                        }
              if (oddelenie == CHIR) // ak nieje volna kapacita,pacient je preposlany do inej nemocnice
                        {
                            vs_p_chir++;
                            if (!chir.Full()) akce();
                        }

	}

	void GenerateStarostlivost1()
	{
	  St1tm=new St1Timeout(this);

	  double next;

	  if (oddelenie==INTERNE)
              {
              if (hodin(Time) >= 7 && hodin(Time) < 14) next=Uniform(2*60,4*60);
              else next=Uniform(6*60,8*60);
              if (hodin(Time+next) >= 7 ) next=time_to(7)+Uniform(2*60,4*60);
              }
      if (oddelenie==ARO) next=Uniform(30,2*60);

      if (oddelenie==CHIR)
              {
              if (hodin(Time) >= 7 && hodin(Time) < 14) next=Uniform(1*60,3*60);
              else next=Uniform(5*60,15*60);
              if (hodin(Time+next) >= 7 ) next=time_to(7)+Uniform(1*60,3*60);
              }

      St1tm->Activate(Time + next); // nastav timeout pre Starostlivost1

	  Starostlivost1 *ptr=new Starostlivost1;
	  ptr->oddelenie=oddelenie;
	  ptr->Activate();

	}

	void GenerateStarostlivost2()
	{
	  St2tm=new St2Timeout(this);
      if (oddelenie == INTERNE) St2tm->Activate(Time + Uniform(20*60,200*60)); // nastav timeout pre Starostlivost1
      if (oddelenie == ARO) St2tm->Activate(Time + Uniform(12*60,100*60)); // nastav timeout pre Starostlivost1
      if (oddelenie == CHIR) St2tm->Activate(Time + Uniform(40*60,300*60)); // nastav timeout pre Starostlivost1

	  Starostlivost2 *ptr=new Starostlivost2(this);
	  ptr->oddelenie=oddelenie;
	  ptr->Activate();


	}

    // pacient zomiera
	void die()
	{
	    St1tm->Cancel(); //zrusi casovace
	    St2tm->Cancel();
	    if (oddelenie == INTERNE) {Leave(interne,1);zomrelo_int++;} //uvolni oddelenie
	    if (oddelenie == ARO) {Leave(aro,1);zomrelo_aro++;}
	    if (oddelenie == CHIR) {Leave(chir,1);zomrelo_chir++;}
	    zivy=0;


	}
};


 void Starostlivost2::Behavior()
        {
  Priority = 1;
          int dead=0;
          double ac_time=Time;
          switch (oddelenie)
          {
              case INTERNE : Enter(lekari_int,1);Enter(sestry_int,1);c_st2_int(Time-ac_time);break;
              case ARO : Enter(lekari_aro,1);Enter(sestry_aro,1);c_st2_aro(Time-ac_time);break;
              case CHIR : Enter(lekari_chir,1);Enter(sestry_chir,1);c_st2_chir(Time-ac_time);break;
          }

          switch (oddelenie)
          {                         //ak bolo cakanie dlhsie ako X,pacient zomiera,konstatovanie smrti 3min
              case INTERNE : if (Time-ac_time > Uniform(5,25)) {To->die();c_um_int(hodin(Time));Wait(3);dead=1;}break;
              case ARO : if (Time-ac_time > Uniform(4,10)) {To->die();c_um_aro(hodin(Time));Wait(3);dead=1;}break;
              case CHIR : if (Time-ac_time > Uniform(5,25)) {To->die();c_um_chir(hodin(Time));Wait(3);dead=1;}break;
          }

          if (dead==0)
          {
          Wait(Uniform(5,40));
          if (oddelenie==INTERNE)if(Random()<0.04) {To->die();c_um_int(hodin(Time));}  // Starostlivost2 je uspesna v 96%,v 4% pacient zomiera
          if(oddelenie==ARO)     if(Random()<0.05) {To->die();c_um_aro(hodin(Time));}  // Starostlivost2 je uspesna v 95%,v 5% pacient zomiera
          if(oddelenie==CHIR)     if(Random()<0.10) {To->die();c_um_chir(hodin(Time));} // Starostlivost2 je uspesna v 94%,v 6% pacient zomiera
          }
          switch (oddelenie)
          {
              case INTERNE : Leave(lekari_int,1);Leave(sestry_int,1);break;
              case ARO : Leave(lekari_aro,1);Leave(sestry_aro,1);break;
              case CHIR : Leave(lekari_chir,1);Leave(sestry_chir,1);break;
          }

        }



void St1Timeout::Behavior()
{
To->GenerateStarostlivost1();
Cancel();
}

void St2Timeout::Behavior()
{
To->GenerateStarostlivost2();
Cancel();
}

// proces zaberie lekarov ktori poobede odchadzaju a maju volno
class VolnoDoktor : public Process
{
    void Behavior()
    {
        Enter(lekari_int,2);
        Enter(lekari_chir,3);
        Wait(15*60);
        Leave(lekari_chir,3);
        Leave(lekari_int,2);
    }
};
// proces zaberie sestry ktore poobede odchadzaju a maju volno
class VolnoSestra : public Process
{
    void Behavior()
    {
        Enter(sestry_int,1);
        Enter(sestry_chir,3);
        Wait(16*60);
        Leave(sestry_chir,3);
        Leave(sestry_int,1);
    }
};

//generator procesu volna doktorov
class VolnoDoktorGener : public Event
{
  void Behavior()
  {
      (new VolnoDoktor)->Activate();

      Activate(Time+24*60);
  }


};
// generator procesu volna sestier
class VolnoSestraGener : public Event
{
  void Behavior()
  {
      (new VolnoSestra)->Activate();

      Activate(Time+24*60);
  }


};

// generator pacientov prichadzajucich na interne oddelenie
class GenerINT : public Event {
	void Behavior()
	{
		Pacient *ptr=new Pacient;
		ptr->oddelenie=INTERNE;
		ptr->Activate();
		prichod_p_int(hodin(Time));
		double next;
		//int hodin=((int)Time / 60 ) % 24;

		if (hodin(Time) >= 8 && hodin(Time) < 13)
		{
        next=Uniform(30,4*60);


		if (hodin(Time + next) >= 13)
		 {
		     next=Uniform(0*60,20*60);
		 }
		}
		else
		{
		    next=Uniform(0*60,20*60);
		    if ( next >  time_to(8))
		    next=time_to(7)+Uniform(1*60,3*60);

		}
		Activate(Time+next);
	}
};

// generator pacientov prichadzajucich na ARO oddelenie
class GenerARO : public Event {
	void Behavior()
	{
		Pacient *ptr=new Pacient;
		ptr->oddelenie=ARO;
		ptr->Activate();
		prichod_p_aro(hodin(Time));
		double next;
        next=Uniform(24*60,48*60);
        Activate(Time+next);
	}
};

// generator pacientov prichadzajucich na chirurgicke oddelenie
class GenerCHIR : public Event {
	void Behavior()
	{
		Pacient *ptr=new Pacient;
		ptr->oddelenie=CHIR;
		ptr->Activate();
		prichod_p_chir(hodin(Time));
		double next;
		//int hodin=((int)Time / 60 ) % 24;

		if (hodin(Time) >= 8 && hodin(Time) < 13)
		{
        next=Uniform(1*60,5*60);


		if (hodin(Time + next) >= 13)
		 {
		     next=Uniform(5*60,25*60);
		 }
		}
		else
		{
		    next=Uniform(5*60,25*60);
		    if ( next >  time_to(8))
		    next=time_to(7)+Uniform(1*60,5*60);
		}
		Activate(Time+next);
	}
};
int main()
{
	Init(0,60*24*180); // pol roka
	(new GenerINT)->Activate();
	(new GenerARO)->Activate();
	(new GenerCHIR)->Activate();
	(new VolnoDoktorGener)->Activate(15*60); //Doktori odchadzaju o 15:00
	(new VolnoSestraGener)->Activate(14*60); //Sestry odchadzaju o 14:00

	Run();
	Print("-----------------------INTERNE ODDELENIE----------------------\n");
	Print("--------------------------------------------------------------\n");
	interne.Output();
	sestry_int.Output();
	lekari_int.Output();
	c_st1_int.Output();
	c_st2_int.Output();
	c_um_int.Output();
	prichod_p_int.Output();
	Print("Celkom hospitalizovanych pacientov %i \n",hosp_p_int);
	Print("Pravdepodobnost, ze pacient bude prijaty: %f\n", (float)hosp_p_int/vs_p_int);
	Print("Celkovo zomrelo %i pacientov,tj. %f\n\n",zomrelo_int,(float)zomrelo_int/hosp_p_int);
	Print("-------------------------ARO ODDELENIE------------------------\n");
	Print("--------------------------------------------------------------\n");
	aro.Output();
	sestry_aro.Output();
	lekari_aro.Output();
	c_st1_aro.Output();
	c_st2_aro.Output();
	c_um_aro.Output();
	prichod_p_aro.Output();
	Print("Celkom hospitalizovanych pacientov %i \n",hosp_p_aro);
	Print("Pravdepodobnost, ze pacient bude prijaty: %f\n", (float)hosp_p_aro/vs_p_aro);
	Print("Celkovo zomrelo %i pacientov,tj. %f\n\n",zomrelo_aro,(float)zomrelo_aro/hosp_p_aro);
	Print("---------------------CHIRURGICKE ODDELENIE--------------------\n");
	Print("--------------------------------------------------------------\n");
	chir.Output();
	sestry_chir.Output();
	lekari_chir.Output();
	c_st1_chir.Output();
	c_st2_chir.Output();
	c_um_chir.Output();
	prichod_p_chir.Output();
	Print("Celkom hospitalizovanych pacientov %i \n",hosp_p_chir);
	Print("Pravdepodobnost, ze pacient bude prijaty: %f\n", (float)hosp_p_chir/vs_p_chir);
	Print("Celkovo zomrelo %i pacientov,tj. %f\n",zomrelo_chir,(float)zomrelo_chir/hosp_p_chir);



}
